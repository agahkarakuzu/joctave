function count=mlpprintf(pid,format,data)
% count=mlpprintf(pid,format,data)

if (nargin<3)
    help(mfilename)
    return
end

count=mlpmex(pid,'printf',format,data);

