function varargout=mlpscanf(pid,format,sz)
% [data,count]=mlpscanf(pid,format [,size])

if (nargin<2)
    help(mfilename)
    return
end

if (~exist('sz','var') | isempty(sz))
    sz=0;
end

[data,count]=mlpmex(pid,'scanf',format,sz);

if (nargout>0)
    varargout{1}=data;
end
if (nargout>1)
    varargout{2}=count;
end
